package com.example.riverpod_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
