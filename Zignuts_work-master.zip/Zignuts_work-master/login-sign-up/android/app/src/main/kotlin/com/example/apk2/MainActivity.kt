package com.example.apk2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
